﻿#include <iostream>  // Підключення бібліотеки для роботи з введенням/виведенням
#include "array_utils.h"  // Підключення заголовочного файлу для масивів
#include "matrix_utils.h" // Підключення заголовочного файлу для матриць

using namespace std; // Використання стандартного простору імен (щоб не писати std::)

void menu() {
    while (true) { // Нескінченний цикл для відображення меню, поки користувач не вибере вихід
        int choice;
        cout << "\nMenu:\n";
        cout << "1. Task 1: Reverse subarray between K and L\n"; // Опція 1 — переворот підмасиву
        cout << "2. Task 2: Calculate product of each column\n"; // Опція 2 — добуток елементів у кожному стовпці матриці
        cout << "3. Task 3: Binary Insertion Sort\n"; // Опція 3 — бінарне сортування вставками
        cout << "4. Exit\n"; // Вихід з програми
        cout << "Choose an option: ";
        cin >> choice;

        switch (choice) { // Обробка вибору користувача
        case 1:
            task1(); // Виконати завдання 1
            break;
        case 2:
            task2(); // Виконати завдання 2
            break;
        case 3:
            task3(); // Виконати завдання 3
            break;
        case 4:
            return; // Вихід з меню
        default:
            cout << "Invalid choice, please try again.\n"; // Повідомлення про невірний вибір
        }
    }
}

int main() {
    menu(); // Запуск меню при старті програми
    return 0;
}