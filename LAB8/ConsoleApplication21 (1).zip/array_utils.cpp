﻿#include "array_utils.h"
#include <iostream>
#include <fstream> // Для роботи з файлами
#include <algorithm> // Для std::reverse

using namespace std;

// Зчитування масиву з файлу
void inputArrayFromFile(vector<int>& arr, int& n, const string& filename) {
    ifstream infile(filename); // Відкриття файлу для читання
    if (!infile) {
        cerr << "Cannot open file: " << filename << endl;
        return;
    }

    int num;
    while (infile >> num) { // Зчитування чисел до кінця файлу
        arr.push_back(num);
    }
    n = arr.size(); // Встановлення розміру масиву
    infile.close(); // Закриття файлу
}

// Запис масиву у файл
void outputArrayToFile(const vector<int>& arr, const string& filename) {
    ofstream outfile(filename); // Відкриття файлу для запису
    for (int val : arr) {
        outfile << val << " "; // Запис елементів через пробіл
    }
    outfile << endl;
    outfile.close(); // Закриття файлу
}

// Реверс частини масиву від індексу (k-1) до (l-1)
void reverseSubarray(vector<int>& arr, int k, int l) {
    reverse(arr.begin() + (k - 1), arr.begin() + l);
}

// Бінарне сортування вставками
void binaryInsertionSort(vector<int>& arr) {
    for (int i = 1; i < arr.size(); ++i) {
        int key = arr[i];
        int left = 0, right = i;

        // Знаходимо позицію вставки за допомогою бінарного пошуку
        while (left < right) {
            int mid = (left + right) / 2;
            if (key < arr[mid])
                right = mid;
            else
                left = mid + 1;
        }

        // Зсуваємо елементи і вставляємо key у правильну позицію
        for (int j = i; j > left; --j) {
            arr[j] = arr[j - 1];
        }

        arr[left] = key;
    }
}

// Виконання завдання 1
void task1() {
    int n, k, l;
    vector<int> arr;
    string inputFileName, outputFileName;

    cout << "Enter input filename: ";
    cin >> inputFileName;
    cout << "Enter output filename: ";
    cin >> outputFileName;

    inputArrayFromFile(arr, n, inputFileName);
    if (arr.empty()) {
        cout << "Input array is empty or file could not be read." << endl;
        return;
    }

    cout << "Enter K and L (1 ≤ K < L ≤ N): ";
    cin >> k >> l;

    // Перевірка правильності значень
    if (k < 1 || l < 1 || k >= l || l > n) {
        cout << "Invalid values for K and L. Ensure that 1 ≤ K < L ≤ N." << endl;
        return;
    }

    reverseSubarray(arr, k, l);
    outputArrayToFile(arr, outputFileName);
    cout << "Modified array written to " << outputFileName << endl;
}

// Виконання завдання 3
void task3() {
    int n;
    vector<int> arr;
    string inputFileName, outputFileName;

    cout << "Enter input filename: ";
    cin >> inputFileName;
    cout << "Enter output filename: ";
    cin >> outputFileName;

    inputArrayFromFile(arr, n, inputFileName);
    if (arr.empty()) {
        cout << "Input array is empty or file could not be read." << endl;
        return;
    }

    binaryInsertionSort(arr);
    outputArrayToFile(arr, outputFileName);

    cout << "Sorted array written to " << outputFileName << endl;
}